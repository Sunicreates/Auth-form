import React from 'react';
import ReactDOM from 'react-dom/client';

import KK  from './App.jsx';

ReactDOM.createRoot( 
  document.querySelector('#root')
).render(<KK />)